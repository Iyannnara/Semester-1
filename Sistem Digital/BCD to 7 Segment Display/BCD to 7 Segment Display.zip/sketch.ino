
const int pinA = 2;
const int pinB = 3;
const int pinC = 4;
const int pinD = 5;
const int pinE = 6;
const int pinF = 7;
const int pinG = 8;
const int pinDP = 9;

const byte segmentPins[] = {pinA, pinB, pinC, pinD, pinE, pinF, pinG};

//saklar
const int pinInputA = 13; // A
const int pinInputB = 12; // B 
const int pinInputC = 11; // C 
const int pinInputD = 10; // D 

const byte polaBCD[10][7] = {
  {1, 1, 1, 1, 1, 1, 0}, // 0
  {0, 1, 1, 0, 0, 0, 0}, // 1
  {1, 1, 0, 1, 1, 0, 1}, // 2
  {1, 1, 1, 1, 0, 0, 1}, // 3
  {0, 1, 1, 0, 0, 1, 1}, // 4
  {1, 0, 1, 1, 0, 1, 1}, // 5
  {1, 0, 1, 1, 1, 1, 1}, // 6
  {1, 1, 1, 0, 0, 0, 0}, // 7
  {1, 1, 1, 1, 1, 1, 1}, // 8
  {1, 1, 1, 1, 0, 1, 1}  // 9 
};

void setup() {
  
  for (int i = 0; i < 7; i++) {
    pinMode(segmentPins[i], OUTPUT);
  }
  pinMode(pinDP, OUTPUT);

 
  pinMode(pinInputA, INPUT);
  pinMode(pinInputB, INPUT);
  pinMode(pinInputC, INPUT);
  pinMode(pinInputD, INPUT);
}

void loop() {
  
  int A = digitalRead(pinInputA);
  int B = digitalRead(pinInputB);
  int C = digitalRead(pinInputC);
  int D = digitalRead(pinInputD);


  int nilaiDesimal = (A * 8) + (B * 4) + (C * 2) + (D * 1);

  //decoder BCD
  if (nilaiDesimal <= 9) {
  
    for (int i = 0; i < 7; i++) {
      digitalWrite(segmentPins[i], polaBCD[nilaiDesimal][i]);
    }
  } else {

    for (int i = 0; i < 7; i++) {
      digitalWrite(segmentPins[i], LOW);
    }
  }


  digitalWrite(pinDP, (nilaiDesimal > 0) ? HIGH : LOW);

  delay(50); 
}
